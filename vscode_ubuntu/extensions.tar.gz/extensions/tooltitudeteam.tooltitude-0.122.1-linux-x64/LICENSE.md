## END USER LICENSE AGREEMENT FOR TOOLTITUDE

**LAST UPDATED ON 01/04/2024**

This End User License Agreement (this "Agreement") is a legally binding contract between Tooltitude LLC, a Limited Liability Company organized under the laws of the State of Delaware ("Vendor"), and an individual end user ("You," "Your", "Customer"). 

It applies to the "Tooltitude for Go" extension provided under this Agreement, including all its versions unless a specific version is accompanied by a different version of this Agreement (the "Software"). 

You agree that when You use the Software, You will do so subject to this Agreement. DO NOT ACCESS OR USE THE SOFTWARE IF YOU ARE UNWILLING OR UNABLE TO BE BOUND BY THIS AGREEMENT.

EACH PARTY ACKNOWLEDGES THAT IT HAS READ THIS AGREEMENT, UNDERSTANDS IT, AND AGREES TO BE BOUND BY ITS TERMS, AND THAT THE PERSON SIGNING ON ITS BEHALF HAS BEEN AUTHORIZED TO DO SO. THE PERSON EXECUTING THIS AGREEMENT ON CUSTOMER’S BEHALF REPRESENTS THAT HE OR SHE HAS THE AUTHORITY TO BIND CUSTOMER TO THESE TERMS AND CONDITIONS.

This Agreement is effective as of the date You click "Agree" or otherwise indicate Your consent to be bound by this Agreement (the "Effective Date"). 

# 1. General

## 1.1 Eligibility
You represent and warrant that You are 18 years old or older, and You recognize and agree that You must be 18 years old or older to use the Software.

## 1.2 Software Revisions
Vendor may revise the features and functions of the Software at any time. 

## 1.3 License Fees
Software includes features that are only accessible upon payment of the required license fees ("Premium Features"). 
License fees are paid through a reseller, Lemon Squeezy, LLC ("Reseller") according to buyer terms: https://www.lemonsqueezy.com/buyer-terms
When you place an order through Reseller, there will be associated restrictions that you shall follow.
Your order may be canceled or declined by Vendor for reasons of product availability changes, inaccuracies in description or pricing, or order errors; a refund of the license fees shall be provided in such instances; in all other cases Vendor will not be required to refund fees under any circumstances.

## 1.4 Subscriptions
Vendor may provide options to pay licensee fees on a subscription basis; a subscription continues until canceled either by You or Vendor.
If Vendor changes Your subscription product including its price, Vendor shall send a notification to the email on file at least 10 days before the changes takes effect; if You don't agree to continue the subscription, You shall cancel. 
Keeping the subscription indicates your agreement to continue the subscription with the changes; You shall keep Your email on file updated and checked regularly.

# 2. License 

## 2.1 License
Vendor hereby grants Customer a nonexclusive license to reproduce and use any number of copies of the Software during the Term, provided Customer complies with the restrictions set forth in Section 2.2 below.

## 2.2 Restrictions on Software Rights
Copies of the Software created or transferred pursuant to this Agreement are licensed, not sold, and Customer receives no title to or ownership of any copy or of the Software itself. 
Furthermore, Customer receives no rights to the Software other than those specifically granted in Section 2.1 above. 
Without limiting the generality of the foregoing, Customer shall not: 
(a) modify, create derivative works from, distribute, publicly display, publicly perform, or sublicense the Software; 
(b) use the Software for service bureau or time-sharing purposes or in any other way allow third parties to exploit the Software; 
(c) reverse engineer, decompile, disassemble, or otherwise attempt to derive any of the Software’s source code;
(d) using the Software contrary to the law; 
(e) use Premium Features without paying required license fees; 
(f) use Premium Features contrary to restrictions associated with the relevant order. 

# 3. Data

## 3.1 Privacy Policy & Compliance
You acknowledge Vendor's privacy policy https://www.tooltitude.com/privacy, and You recognize and agree that nothing in this Agreement restricts Vendor’s right to alter such privacy policy. 
If Vendor receives a "right to know", deletion, "right to be forgotten", or similar request related to Your data, Vendor may respond in accordance with applicable law. 
Nothing in this Agreement precludes Vendor from asserting rights or defenses it may have under applicable law related to such requests.

## 3.2 Opt out of De-identified Data Collection
You acknowledge that Vendor may collect De-Identified Data (as defined below). 
You further acknowledge that You may opt out of such data collection by following the instruction in the VS Code documentation: https://code.visualstudio.com/docs/supporting/faq#_how-to-disable-telemetry-reporting (The Software respects the system wide telemetry.telemetryLevel setting). 
You may do so either prior to accepting this agreement or at any later moment. 
By using the Software without opting out, You give Your consent to such data collection. 
("De-Identified Data" refers to Your data with the following removed: information that identifies or could reasonably be used to identify You, an individual person, or a household.)

## 3.3 De-Identified Data
Vendor may use, reproduce, sell, publicize, or otherwise exploit De-Identified Data in any way, in its sole discretion, including without limitation aggregated with data from other customers. 

# 4. IP & Feedback

## 4.1 IP Rights in the Software
Vendor retains all right, title, and interest in and to the Software, including without limitation updates, except to the extent of the limited licenses specifically set forth in Sections 2.1 (Licenses). 
Customer recognizes that the Software and its components are protected by copyright and other laws.

## 4.2 Feedback
Customer hereby grants Vendor a perpetual, irrevocable, worldwide license to use any Feedback (as defined below) Customer communicates to Vendor, without compensation, without any obligation to report on such use, and without any other restriction. 
Vendor’s rights granted in the previous sentence include, without limitation, the right to exploit Feedback in any and every way, as well as the right to grant sublicenses. 
("Feedback" refers to any suggestion or idea for modifying any of Vendor’s products or services, including without limitation all intellectual property rights in any such suggestion or idea.)

# 5. Term & Termination

## 5.1 Term
The term of this Agreement (the "Term") will commence on the Effective Date and continue until terminated by either You or Vendor.

## 5.2 Termination
You may terminate this Agreement by deleting the Software from all Your computers. 
Vendor may terminate this Agreement by notifying You in writing, including without limitation via notification in the Software.
In case of termination, Vendor may refund You subscription fees at its own discretion.

## 5.3. Effects of Termination
Upon termination of this Agreement, You shall cease all use of the Software, and delete, destroy, or return all copies of the Software in Your possession or control. 
The following provisions will survive termination of this Agreement: Articles 4 (IP & Feedback), 5.3 (Effects of Termination), 6 (Disclaimers), 7 (Limitation of Liability), 8 (Indemnification) and 9 (Miscellaneous); and any other provision of this Agreement that must survive to fulfill its essential purpose. 

# 6. Disclaimers

## 6.1 Warranty Disclaimers
YOU AGREE THAT YOU ACCEPT THE SOFTWARE "AS IS" AND AS AVAILABLE, WITH NO REPRESENTATION OR WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NONINFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS, OR ANY IMPLIED WARRANTY ARISING FROM STATUTE, COURSE OF DEALING, COURSE OF PERFORMANCE, OR USAGE OF TRADE. WITHOUT LIMITING THE GENERALITY OF THE FOREGOING: 
(a) VENDOR HAS NO OBLIGATION TO INDEMNIFY OR DEFEND YOU AGAINST CLAIMS RELATED TO INFRINGEMENT OF INTELLECTUAL PROPERTY; 
(b) VENDOR DOES NOT REPRESENT OR WARRANT THAT THE SOFTWARE WILL PERFORM WITHOUT INTERRUPTION OR ERROR; 
(c) VENDOR DOES NOT REPRESENT OR WARRANT THAT THE SOFTWARE IS SECURE FROM HACKING OR OTHER UNAUTHORIZED INTRUSION OR THAT YOUR DATA WILL REMAIN PRIVATE OR SECURE; AND 
(d) VENDOR DISCLAIMS ANY REPRESENTATION OR WARRANTY CONCERNING PRODUCTS OR SERVICES PROVIDED BY OTHER USERS OF THE SOFTWARE OR OTHER THIRD PARTIES.

## 6.2 Third Party Sites and Content
You understand that the Software may contain or send You links to third party websites, applications or features not owned or controlled by Vendor ("Third Party Sites"), and that links to Third Party Sites may also appear in content available to You through the Software. 
The Software may also enable interaction between the Software and a Third Party Site through applications that connect the Software with a Third Party Site. 
Through Third Party Sites You may be able to access content from third parties that Vendor does not control and/or share Your content with others. 
YOU ACCESS THIRD PARTY SITES ENTIRELY AT YOUR OWN RISK, AND VENDOR WILL HAVE NO LIABILITY FOR YOUR USE OF OR ACCESS TO THIRD PARTY SITES AND/OR THIRD PARTY CONTENT.

# 7. Limitations of Liability

## 7.1 Dollar Cap
VENDOR'S CUMULATIVE LIABILITY FOR ALL CLAIMS ARISING OUT OF OR RELATED TO THIS AGREEMENT WILL NOT EXCEED $7.00.

## 7.2 Excluded Damages
IN NO EVENT WILL VENDOR BE LIABLE FOR LOST PROFITS OR LOSS OF BUSINESS OR FOR ANY CONSEQUENTIAL, INDIRECT, SPECIAL, INCIDENTAL, OR PUNITIVE DAMAGES ARISING OUT OF OR RELATED TO THIS AGREEMENT.

## 7.3 Clarifications & Disclaimers
THE LIABILITIES LIMITED BY THIS ARTICLE 7 APPLY TO THE BENEFIT OF VENDOR'S OFFICERS, DIRECTORS, EMPLOYEES, AGENTS, AND THIRD PARTY CONTRACTORS, AS WELL AS: 
(a) TO LIABILITY FOR NEGLIGENCE; 
(b) REGARDLESS OF THE FORM OF ACTION, WHETHER IN CONTRACT, TORT, STRICT PRODUCT LIABILITY, OR OTHERWISE; 
(c) EVEN IF VENDOR IS ADVISED IN ADVANCE OF THE POSSIBILITY OF THE DAMAGES IN QUESTION AND EVEN IF SUCH DAMAGES WERE FORESEEABLE; AND 
(d) EVEN IF YOUR REMEDIES FAIL OF THEIR ESSENTIAL PURPOSE. 
You acknowledge and agree that Vendor has based its pricing on and entered into this Agreement in reliance upon the limitations of liability and disclaimers of warranties and damages in this ARTICLE 7 and elsewhere in this Agreement and that such terms form an essential basis of the bargain between the parties. 
If applicable law limits the application of the provisions of this ARTICLE 7, Vendor’s liability will be limited to the maximum extent permissible.

# 8. Indemnification

## 8.1 Indemnification
Customer shall defend, indemnify, and hold harmless Vendor and Vendor Associates (meaning Vendor's officers, directors, shareholders, parents, subsidiaries, agents, successors, and assigns) against any "Indemnified Claim", meaning any third party claim, suit, or proceeding arising out of, related to, or alleging an injury or loss caused by Customer's alleged or actual use of, misuse of, or failure to use the Software.

# 9. Miscellaneous

## 9.1 Independent Contractors
The parties are independent contractors. Neither party is the agent of the other, and neither may make commitments on the other’s behalf. 

## 9.2 Assignment & Successors
You may not assign this Agreement or any of Your rights or obligations under this Agreement without Vendor’s express written consent. 
Except to the extent forbidden in this Section 9.2, this Agreement will be binding upon and inure to the benefit of the parties’ respective successors and assigns.

## 9.3 Severability
To the extent permitted by applicable law, the parties hereby waive any provision of law that would render any clause of this Agreement invalid or otherwise unenforceable in any respect. 
In the event that a provision of this Agreement is held to be invalid or otherwise unenforceable, such provision will be interpreted to fulfill its intended purpose to the maximum extent permitted by applicable law, and the remaining provisions of this Agreement will continue in full force and effect.

## 9.4 No Waiver
Neither party will be deemed to have waived any of its rights under this Agreement by lapse of time or by any statement or representation other than by an authorized representative in an explicit written waiver. 
No waiver of a breach of this Agreement will constitute a waiver of any other breach of this Agreement.

## 9.5 U.S. Government Restricted Rights
This Section applies to all acquisitions of the Software by or for the United States federal government, including by any prime contractor or subcontractor (at any tier) under any contract, grant, cooperative agreement, or other activity with the Federal government. The Software and related documentation were developed at private expense and are "Commercial Items," as that term is defined at 48 C.F.R. §2.101, consisting of "Commercial Computer Software" and "Commercial Computer Software Documentation," as such terms are used in 48 C.F.R. §12.212 (for civilian agencies) and 48 C.F.R. §227.7202 (for Department of Defense agencies), as applicable. Consistent with and subject to 48 CFR 12.212  and 48 CFR 227.7202-1 through 227.7702-4, as applicable, the Commercial Computer Software and Commercial Computer Software Documentation are being licensed to U.S. Government end users (a) only as Commercial Items and (b) with only such rights as are granted to all other end-users pursuant to the terms herein. Any provisions of this Agreement inconsistent with federal procurement regulations or other federal law are not enforceable against the U.S. Government. Unpublished rights are reserved under the copyright laws of the United States. Customer shall not remove or deface any restricted rights notice or other legal notice appearing in the Software or on any packaging or other media associated with the Software. This Section does not grant Customer any rights not specifically set forth in this Agreement, including without limitation any right to distribute the Software to the United States federal government.

## 9.6 Choice of Law & Jurisdiction
This Agreement will be governed solely by the internal laws of the State of Delaware, including without limitation applicable federal law, without reference to: 
(a) any conflicts of law principle that would apply the substantive laws of another jurisdiction to the parties’ rights or duties; 
(b) the 1980 United Nations Convention on Contracts for the International Sale of Goods; or 
(c) other international laws. 
The parties consent to the personal and exclusive jurisdiction of the federal and state courts of Dover, Delaware. This Section and Section 9.11 below (Dispute Resolution) govern all claims arising out of or related to this Agreement, including without limitation tort claims.

## 9.7 Force Majeure
No delay, failure, or default, other than a failure to pay fees when due, will constitute a breach of this Agreement to the extent caused by epidemics, acts of war, terrorism, hurricanes, earthquakes, other acts of God or of nature, strikes or other labor disputes, riots or other acts of civil disorder, embargoes, government orders responding to any of the foregoing, or other causes beyond the performing party’s reasonable control.

## 9.8 Technology Export
Customer shall not: 
(a) permit any third party to access or use the Software in violation of any U.S. law or regulation; or 
(b) export the Software or otherwise remove it from the United States except in compliance with all applicable U.S. laws and regulations. 
Without limiting the generality of the foregoing, Customer shall not permit any third party to access or use the Software in, or export it to, a country subject to a United States embargo.

## 9.9 Entire Agreement
This Agreement sets forth the entire agreement of the parties and supersedes all prior or contemporaneous writings, negotiations, and discussions with respect to its subject matter. 
Neither party has relied upon any such prior or contemporaneous communications.

## 9.10 Amendment
This Agreement may not be amended in any other way except through a written agreement by authorized representatives of each party.

## 9.11 Dispute Resolution
Any legal disputes or claims arising out of or related to this Agreement (including without limitation claims related to the use of the Software, the interpretation, enforceability, revocability, or validity of the Agreement, or the arbitrability of any dispute), that cannot be resolved informally shall be submitted to binding arbitration in Dover, DE. 
The arbitration will be conducted by the American Arbitration Association under its Commercial Arbitration Rules, or as otherwise mutually agreed by You and Vendor. 
Any judgment on the award rendered by the arbitrator may be entered in any court having jurisdiction thereof. 
Claims must be brought within the statute of limitations or other time required by applicable law. 
You agree that You shall bring any claim, action or proceeding arising out of or related to the Agreement in Your individual capacity, and not as a plaintiff or class member in any purported class, collective, or representative proceeding. 
The arbitrator may not consolidate the claims of more than one person and may not otherwise preside over any form of a representative, collective, or class proceeding. 
YOU ACKNOWLEDGE AND AGREE THAT YOU AND VENDOR ARE EACH WAIVING THE RIGHT TO A TRIAL BY JURY OR TO PARTICIPATE AS A PLAINTIFF OR CLASS MEMBER IN ANY PURPORTED CLASS ACTION OR REPRESENTATIVE PROCEEDING IN ANY FORUM, INCLUDING WITHOUT LIMITATION CLASS-WIDE ARBITRATION AND PRIVATE ATTORNEY-GENERAL ACTIONS.