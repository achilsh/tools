# Tooltitude Changelog
This list contains highlights of notable changes in each version.
⭐ indicates changes related to premium features (https://www.tooltitude.com/pricing)

## 03/27/2025 v0.122.0
- (BUG) Fixed panic in case of non file:/// url as the first root in a workspace
- (BUG) More resilence to siutations where a lot of panics happens in a row

## 03/18/2025 v0.121.0
- (BUG) Fixed failure to navigate to the implementing method when the method uses type alias as the receiver
- (BUG) Fixed handling of symlinks

## 03/12/2025 v0.120.0
- (FEATURE) Improved diagnostics

## 03/08/2025 v0.119.0
- (BUG) Fixed file sync related panics in some cases

## 03/03/2025 v0.118.0
- (FEATURE) Always separate an added import with a newline from other top level declarations
- (BUG) Fixed name conflicts in case of code modifications (including declaration moves)
- (BUG) Fixed panic on import sorting
- ⭐(BUG) Fixed panic on automatic package rename on folder rename in cases of go.mods deep in the folder, as well as renames in the vendor folder

## 02/26/2025 v0.117.0
- ⭐(BUG) Fixed various issues with renames and moves

## 02/18/2025 v0.116.0
- (FEATURE) Interrupt typechecker if it runs for too long

## 02/15/2025 v0.115.0

## 02/10/2025 v0.114.0
- (FEATURE) Improved diagnostics

## 02/06/2025 v0.113.0
- (FEATURE) Improved diagnostics

## 01/28/2025 v0.112.0
- (BUG) Fixed a number of file watching issues

## 01/20/2025 v0.111.0
- (FEATURE) Support for generic type aliases

## 01/16/2025 v0.110.0
- (FEATURE) The tooltitude.checkEmptyIntfcsEnabled setting
- (FEATURE) The tooltitude.checkRedundantParensEnabled setting
- (FEATURE) The tooltitude.iterableExprStmtsEnabled setting

## 01/09/2025 v0.109.0
- (FEATURE) Improved diagnostics

## 01/02/2025 v0.108.0
- (FEATURE) Improved diagnostics

## 12/31/2024 v0.107.0
- (FEATURE) Improved diagnostics

## 12/19/2024 v0.106.0
- (FEATURE) Improved diagnostics

## 12/13/2024 v0.105.0
- (BUG) Fixed incorrect file synchronization with the disk in some cases
- (FEATURE) Improved diagnostics

## 12/06/2024 v0.104.0
- (BUG) Fixed debugging of table tests in situation where there's an anonymous function on the first line of the loop

## 11/28/2024 v0.103.0
- (BUG) Fixed incorect implementation counts when alias used as a receiver type
- (FEATURE) Improved diagnostics

## 11/21/2024 v0.102.0
- (OPTIMIZATION) Optimized parsing speed
- (BUG) Fixed too many similar panics reported at the same time in rare cases
- (FEATURE) Improved diagnostics

## 11/17/2024 v0.101.0
- (BUG) Fixed failing navigation to interface implementator in some cases
- (FEATURE) Improved diagnostics

## 11/10/2024 v0.100.0
- (BUG) Fixed moving of methods with non existent receiver type

## 10/25/2024 v0.99.0
- (FEATURE) Improved diagnostics

## 10/18/2024 v0.98.0
- (BUG) Fixed failing change signature actions from a CodeLens, in some cases
- (FEATURE) Improved diagnostics

## 10/10/2024 v0.97.0
- ⭐(FEATURE) Go reference counts for messages, enums, and client call counts for rpc methods in .proto files
- ⭐(FEATURE) Go implementation counts for gRPC server implementations of services, and rpc methods

## 10/08/2024 v0.96.0
- (FEATURE) Navigation to generated files from protobuf messages, and services
- (BUG) Fixed lack of code lenses in case of go.work in a folder below added go.mod

## 10/04/2024 v0.95.0
- (FEATURE) Improved diagnostics

## 09/27/2024 v0.94.0
- (BUG) Resilience to non utf-8 file names

## 09/20/2024 v0.93.0
- (BUG) Fixed incorrect ref counts for type aliases with reference in other packages via a package variables
- (BUG) Don't show builtin func postfix completions on packages
- (BUG) Fixed race condition happening in rare cases on startup leading to incorrect code lenses

## 09/13/2024 v0.92.0
- (BUG) Fixed possible lost changes to go.work files 
- (FEATURE) Improved diagnostics

## 09/06/2024 v0.91.0
- (FEATURE) Improved diagnostics

## 08/30/2024 v0.90.0
- (FEATURE) Improved diagnostics
- ⭐(BUG) Fixed panic on decl moves in rare cases

## 08/23/2024 v0.89.0
- (FEATURE) Improved diagnostics

## 08/16/2024 v0.88.0
- (FEATURE) Type inference for range over funcs (iterators)
- (BUG) Fixed panics on completion in some cases in the full_lsp mode
- (BUG) Fixed incorrect reporting of redundant parenthesis in some cases
- (FEATURE) Improved diagnostics

## 08/09/2024 v0.87.0
- (FEATURE) Improved diagnostics

## 08/02/2024 v0.86.0
- (FEATURE) More resilience to startup errors
- (FEATURE) Improved diagnostics

## 07/26/2024 v0.85.0
- ⭐(BUG) Fixed panic on file moves in some cases
- ⭐(USABILITY) Better handling of errors on the license server side
- (FEATURE) Improved diagnostics

## 07/21/2024 v0.84.0
- (FEATURE) Don't offer to handle returned error for fmt.Printf

## 07/17/2024 v0.83.0
- (FEATURE) Improved diagnostics

## 07/09/2024 v0.82.0
- (FEATURE) Rm all tags code action for field specs
- (FEATURE) Add json tag code action for field specs
- (FEATURE) Selection range support in the full_lsp mode
- (FEATURE) Show decl if find refs is invoked in the full_lsp mode
- (BUG) Fixed failures to start on Windows in some cases
- (BUG) Fixed deadlock in a rare case of only one available core

## 07/05/2024 v0.81.0
- (FEATURE) Improved diagnostics

## 06/29/2024 v0.80.0
- (BUG) Fixed incorrect handling of local type aliases in some cases
- ⭐(BUG) Fixed panics on moving file from package to package in rare cases

## 06/14/2024 v0.79.0
- ⭐(BUG) Fixed not updating references when files moved in some cases
- (BUG) Correctly handle methods with alias receivers in the refs code lens provider
- (BUG) Correctly handle methods with alias receivers in the method interfaces code lens provider
- (CHANGE) Removed tooltitude.workspaceSyncForDownload option. go mod download works file for workspaces.
- (CHANGE) Dependency download process is run with timeout. If dependency download takes > 180s, the download process is terminated

## 06/07/2024 v0.78.0
- ⭐(FEATURE) Update references on file moves
- (FEATURE) Various improvement in the move declarations refactoring
- (FEATURE) Sort imports code action

## 05/31/2024 v0.77.0
- (FEATURE) Remove unused imports is applicable in some cases with broken imports/references
- (BUG) Correct navigation to function local interface declaration's methods
- (BUG) Fixed incorrect variable rename in rare cases when moving declarations
- (FEATURE) Signature in completion for top level functions in the full_lsp mode (builtin signature aren't shown)
- (FEATURE) Action to clear compilation errors if run via the CodeLens provider in the full_lsp mode

## 05/24/2024 v0.76.0
- (BUG) Fixed not shown implemented interfaces in some cases
- (BUG) Improvements in correctness of type inference

## 05/17/2024 v0.75.0
- (BUG) Improvements in correctness of type inference
- (FEATURE) Postfix completion for slice functions
- (FEATURE) Find refs for builtin identifiers work in full_lsp mode (ref counts aren't shown since there are too many of them)
- (FEATURE) Navigation to builtin identifiers declared in the standard library in the full_lsp mode
- (FEATURE) Automatic insertion of () on callable completion items in the full_lsp mode

## 05/12/2024 v0.74.0
- (BUG) Correct positioning of new lines before and after elements inserted by code actions
- (BUG) Improvements in correctness of type inference
- (FEATURE) Type information for functions in completion in the full_lsp mode
- (FEATURE) Signature help in the full_lsp mode

## 05/06/2024 v0.73.0
- (BUG) Improvements in correctness of type inference
- (BUG) Improvements in correctness of formatting
- (BUG) Fixed order of implemented methods in interfaces

## 04/29/2024 v0.72.0
- (BUG) Improvements in correctness of type inference
- (BUG) Improved go installation detection

## 04/17/2024 v0.71.0
- (BUG) Correct type inference for generic varargs

## 04/10/2024 v0.70.0
- (FEATURE) Don't check files outside of the opened module or workspace (i.e. dependencies, standard library, etc)
- (FEATURE) tooltitude.env property for setting custom environment for the tooltitude language server
- (FEATURE) Change signature (for private functions, and non interface methods)
- ⭐(FEATURE) Change signature (for public functions, and non interface methods)
- ⭐(FEATURE) Change signature code action (for functions, and non interface methods)
- (BUG) Fixed incorrect unresolved references in cases of alias use in method receivers
- (BUG) Fixed incorrectly reported unused writes in some cases

## 04/04/2024 v0.69.0
- (FEATURE) Close button in a header of the move decl quick pick
- ⭐(FEATURE) Move between packages for declarations
- (USABILITY) Print detailed cause of failure to find go on a computer
- (BUG) Don't show implement on structs from library code
- (BUG) Don't show mod up/down in library code
- ⭐(BUG) Don't show the move code action in library code

## 03/29/2024 v0.68.0
- (FEATURE) Ability to choose which items to move in the move code command
- (FEATURE) Ability to move between test and non test files in non black box test packages

## 03/21/2024 v0.67.0
- (BUG) Fixed incorrectly reported unused imports
- (BUG) Correctly handle interfaces having comparable constraint in implementation rres
- (BUG) Bugs related to generics in implemented interfaces/implementing types and related CodeLens providers
- (BUG) Interface related CodeLens providers don't consider interface to be implemented if some methods are by pointer, and others by value
- (BUG) Generate generic parameters in the implement interface action
- (BUG) Fixed panic on display of move decl chooser in some cases
- (BUG) Fixed panic on var like postfix completion in some cases

## 03/18/2024 v0.66.0
- (FEATURE) Option to choose whether to move a type with its methods
- (BUG) Fixed incorrect handling of named package imports on decl move
- (BUG) Fixed panic on removing incomplete unused write

## 03/14/2024 v0.65.0
- (FEATURE) Support for moving types and type aliases within the same package
- (FEATURE) Support for moving var declarations (blocks of vars/const under the same var/const)
- (FEATURE) Move up/down code actions for some top level declarations
- (FEATURE) On a type move, its methods from the same file are moved too
- (BUG) Fixed panic on unary postfix completions in some situations

## 03/12/2024 v0.64.0
- (FEATURE) Move declaration CodeLens action for methods and functions (within the same package)
- ⭐(FEATURE) Code action for moving methods and functions (within the same package)
- (FEATURE) tooltitude.codeLens.implIntfc setting to control the "implement interface..." CodeLens provider
- (BUG) Fixed failures on the inline embedded type code action

## 03/06/2024 v0.63.0
- (FEATURE) .ifempty and .ifnempty postfix completions
- (OPTIMIZATION) Reduced lags related to code actions in some cases

## 03/04/2024 v0.62.0
- (BUG) Correctly remove comments in the inline variable code action

## 02/27/2024 v0.61.0
- (FEATURE) Remove unused imports code action
- ⭐(FEATURE) Inline Embedded Struct/Interface code action

## 02/21/2024 v0.60.0
- (FEATURE) Better import handling in the add var type code action

## 02/15/2024 v0.59.0
- (FEATURE) Rewrite dot import code action
- (BUG) Fixed not shown refs view icons for fields and vars
- (BUG) Fixed panic on finding references to built-in symbols
- (BUG) Fixed incorrectly displayed references for targets from external packages in the find refs code action

## 02/10/2024 v0.58.0
- (FEATURE) Rename code action
- (BUG) Show declaration site of a local var in the list of refs if the Show Ref code action is invoked

## 02/07/2024 v0.57.0
- (FEATURE) Show refs code action which shows references in the Tooltitude Refs View

## 02/05/2024 v0.56.0
- (FEATURE) Support iteration over an integer in the for range statement
- ⭐(FEATURE) Synchronize receiver names code action
- ⭐(FEATURE) Extract comments when extracting type

## 01/30/2024 v0.55.0
- (BUG) Fixed dot imports incorrectly reported as unused

## 01/24/2024 v0.54.0
- ⭐(FEATURE) Automatic package imports update on folder renames and moves

## 01/21/2024 v0.53.0
- (BUG) Fixed incorrectly reported broken references after folder moves

## 01/18/2024 v0.52.0
- ⭐(FEATURE) CodeLens provider for finding package imports
- ⭐(FEATURE) Navigational code action for finding package imports
- ⭐(FEATURE) Extract type refactoring (only for anonymous interfaces and structs)

## 01/13/2024 v0.51.0
- (FEATURE) Unused imports checker
- (FEATURE) Remove unused import code action

## 01/08/2024 v0.50.0
- (FEATURE) Ability to run unit tests without the go extension installed
- (USABILITY) Show debug CodeLens actions only if the go extension is installed (otherwise they fail)
- ⭐(BUG) Correctly handle for range statements in debugger inline values
- ⭐(USABILITY) Exclude overly complex values from debugger inline values
- ⭐(FEATURE) Ability to run/debug main/test functions via code action
- ⭐(FEATURE) Ability to see type's implemented interfaces via code action
- ⭐(FEATURE) Ability to see interface's implementations via code action

## 01/04/2024 v0.49.0
- (INTERNAL) Changes related to premium features

## 01/03/2024 v0.48.0
- (FEATURE) Introduced premium features
- (BUG) Fixed incorrect handling of x sign in some informational messages

## 12/28/2023 v0.47.0
- (BUG) Consider installed nightly golang extension as an installed golang extension (used in the debug CodeLens providers)

## 12/16/2023 v0.46.0
- (BUG) Fixed likely cause of postfix completion failures

## 12/01/2023 v0.45.0
- (BUG) Fixed incorrect ignore error action's behavior in some cases
- (BUG) Fixed incorrect unhandled error hint when the expression is inside switch statement

## 11/23/2023 v0.44.0
- (FEATURE) Methods lens for types
- (USABILITY) Icon for the tooltitude references view

## 11/15/2023 v0.43.0
- (BUG) Fixed incorrect generation of stub interfaces in case of single name return result
- (USABILITY) In case a method is implemented through emb type, the "impl method" action adds a method with todo stating that fact

## 10/26/2023 v0.42.0
- (FEATURE) Open issues action

## 10/21/2023 v0.41.0
- (FEATURE) linux-arm64 support (experimental, please report issues if you have any)

## 10/16/2023 v0.40.0
- (FEATURE) Sync Status Icon. Error/Warning status with easy way to see the output of Go commands used for sync.

## 10/09/2023 v0.39.0
- (BUG) Fixed key binding conflict with Cmd+K for clearing terminals

## 10/05/2023 v0.38.0
- (FEATURE) Option to disable unhandled error inspection (tooltitude.unhandledErrorsEnabled)
- (FEATURE) ignore fmt.Println/Print in unhandled error inspection

## 09/29/2023 v0.37.0
- (USABILITY) Better usability of the license agreement workflow (use webview)
- (CHANGE) tooltitude.shadowInspectionEnabled is false by default

## 09/21/2023 v0.36.0
- (OPTIMIZATION) Reduced memory consumption in some situations
- (OPTIMIZATION) Reduced load time in some situations
- (FEATURE) Show implemented methods in the method interfaces lens, not just interfaces

## 09/15/2023 v0.35.0
- (BUG) Fixed not updating of folders with change files in some situations
- (OPTIMIZATION) Reduced memory consumption in some situations

## 09/08/2023 v0.34.0
- (FEATURE) CodeLens actions for debugging table driven tests
- (USABILITY) Activate debug console on debug operations (debug, and debug table test)

## 09/01/2023 v0.33.0
- (FEATURE) 'Analyze unused in path' CodeLens action
- (BUG) Show unused named fields of type declarations in the unused declarations analysis
- (BUG) Enabled inline variable code action. It was disabled by mistake.

## 08/25/2023 v0.32.0
- (FEATURE) Write site inline variable code action
- (BUG) Fixed type computation for generic type constants
- (BUG) Fixed incorrect reference count in cases where there's a method and a variable with the same name in the same package
- (USABILITY) Warn about multifolder workspaces support (i.e. only the first folder works)
- (FEATURE) Ability to see the list of unused symbols in a file (from a CodeLens link at the top of the file, and the command palette)

## 08/18/2023 v0.31.0
- (FEATURE) Don't open refs view if there're no refs
- (FEATURE) Use site inline variable code action

## 08/11/2023 v0.30.0
- (FEATURE) Option to turn off automatic download of project/module dependencies (via tooltitude.downloadDeps)
- (FEATUER) Option to turn off using go work sync for dependency downloads (via tooltitude.workspaceSyncForDownload)
- (BUG) Fixed panics happening in case of opening some files in dependencies of a module
- (BUG) Correctly infer types for higher order function calls with passed generic functions (Allowed since Go 1.21)
- (BUG) Correctly infer types from implemented interfaces' generic  (Allowed since Go 1.21)

## 08/04/2023 v0.29.0
- (OPTIMIZATION) Reduced memory consumption in some situations
- (FEATURE) When there's one reference, the CodeLens provider just navigates to it, not opening any views (you could turn it off with the tooltitude.openOnlyRef setting)
- (FEATURE) Show the target of reference in references view (analogously for interface impls, method impls, and others)

## 07/28/2023 v0.28.0
- (BUG) Fixed incorrect type variable inference in some cases

## 07/18/2023 v0.27.0
- (BUG) Fixed several panics and improved diagnostics

## 07/07/2023 v0.26.0
- (BUG) Fixed language server restarts in some cases

## 06/30/2023 v0.25.0
- (BUG) Fixed incorrect support of whitebox test packages (i.e. abc_test packages)
- (BUG) Fixed startup terminations in some cases

## 06/23/2023 v0.24.0
- (FEATURE) We introduced shortcuts for the references view. Ctrl/Cmd+K Ctrl/Cmd+D - open references view. Ctrl/Cmd+K Ctrl/Cmd+F12 - select next reference. Ctrl/Cmd+K Ctrl/Cmd+Shift+F12 - select prev reference.
- (FEATUER) Generate interface stub code action
- (BUG) Fixed one more case of unresolved references

## 06/09/2023 v0.23.0
- (FEATURE) Stabilize unused writes and related code actions
- (FEATURE) Reference highlighting in editor in case of refs view usage (you could turn it off via tooltitude.refHighlightsEnabled)
- (FEATURE) Command and view menu item to clear references view
- (FEATURE) Better selection of location for interface impl stubs
- (BUG) Incorrectly working broken references in some situations were fixed

## 06/02/2023 v0.22.0
- (FEATURE) Correct extraction of variables from inside of structs i.e. from inside S { s: {x: 1}}, i.e. {x: 1} is extracted as T{x: 1}
- (FEATUER) Experimental unused writes inspection (set tooltitude.unusedWritesEnabled to true)
- (FEATURE) Remove unused assignment code action (Requires enabled unused writes inspection)
- (FEATURE) Replace unused init with var code action (Requires enabled unused writes inspection)

## 05/26/2023 v0.21.0
- (BUG) Don't ignore testdata and vendor directories in package structure in most cases (vendor directory is ignore only if it's both in the root of a module, and contains the modules.txt file)
- (FEATURE) Stabilized reachability checker

## 05/19/2023 v0.20.0
- (BUG) Dependencies are correctly loaded on library add
- (FEATURE) Reachability checker (in development but could be enabled with tooltitude.unreachableStmtsEnabled set to true)

## 05/12/2023 v0.19.0
- (FEATURE) References view is stabilized
- (FEATURE) More resilence to duplicate interface defs in the same packs 

## 05/07/2023 v0.18.0
- (FEATURE) Experimental. Improvements in the references view.

## 05/05/2023 v0.17.0
- (FEATURE) Ability to implement interface
- (FEATURE) Experimental. References view for more Go specific presentation of usages. To enable, set tooltitude.useRefsView to true

## 04/28/2023 v0.16.0
- (FEATURE) More error resistance project loading
- (BUG) Fixed no refs lens in some situation

## 04/21/2023 v0.15.0
- (FEATURE) Reduced RAM consumption on linux

## 04/14/2023 v0.14.0
- (FEAUTRE) Postfix completion for []byte and complex128
- (FEATURE) Ability to disable broken refs and depr symbols inspections

## 04/07/2023 v0.13.0
- (FEATURE) More resilience to errors
- (BUG) Bugs related to position encodings in language server protocol

## 03/30/2023 v0.12.0
- (FEATURE) More postfix completions (functions from the std library)
- (FEATURE) Different icons in postfix completion

## 03/26/2023 v0.11.0
- (BUG) Graceful handling of errors instead of LS termination

## 03/20/2023 v0.10.0
- (FEATURE) Initial set of postfix completions

## 03/19/2023 v0.9.0
- (FEATURE) Suggestions for reporting errors to the github issues
- (BUG) Fixed incorrect variable naming in case of ignoring unhandled exceptions

## 02/28/2023 v0.8.0
- (FEATURE) CodeLens provider to navigate from a method to interfaces it implements
- (FEATURE) CodeLens provider to navigate from a type to interfaces it implements

## 02/27/2023 v0.7.0
- (FEATURE) Implementations/implementing methods CodeLens actions on interfaces
- (FEATURE) Convert else { if to else if { code action

## 02/20/2023 v0.6.0
- (FEATURE) Rename is invoked immediately after a variable is extracted 
- (FEATURE) Handle error code actions don't create new result vars
- (FEATURE) Add remove digit separators in decimal literals
- (FEATURE) Add remove 0o/0O octal prefix in octal literals
- (BUG) Fixed handling of several casts in short var assignment statement
- (BUG) Fixed extra refs results in some cases

## 02/16/2023 v0.5.0
- (FEATURE) Number of references CodeLens provider 
- (FEATURE) Ability to Run/Debug package from a CodeLens provider 
- (FEATURE) Options to disable refs CodeLens provider, and variable shadows inspections

## 02/14/2023 v0.4.0
- (FEATURE) Identifier shadowing inspection
- (FEATURE) Deprecated symbol highlighting

## 02/09/2023 v0.3.0
- (FEATURE) Unwrap else code action (in case of return in the if-true block)
- (BUG) Fixed GLibc compatibility. Now it works on glibc >= 2.17
- (BUG) Exception on navigation to builtin.go

## 02/06/2023 v0.2.0
- (FEATURE) Option to panic on error when there's an unhandled error
- (FEATURE) Option to wrap error when there's an unhandled error
- (FEATURE) Convert defer to multiline defer (via a closure)
- (FEATURE) Add channel receive result code action
- (FEATURE) Add string to raw string literal code action
- (FEATURE) Add raw string to string literal code action
- (BUG) Fixed error happening on invoking the handle unhandled error code action

## 01/31/2023 Initial Release
This is the initial version of the extension.
