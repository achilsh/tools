# Go File Manager

A VS Code extension for managing Go files with features for adding common flows, sorting functions, and integrating with Go tools.

## Features

### 1. Common Flow Management
- Add standardized imports, constants, and interfaces to your Go files
- Maintains consistent structure across your Go codebase

### 2. Function Organization
- Sort functions alphabetically while preserving their associated comments
- Maintain code organization without losing documentation
- Preserve package declarations and imports

### 3. Go Tool Integration
- Format code using `go fmt`
- Run code analysis with `go vet`
- Execute tests with detailed output
- Automatic formatting on save (optional)

## Requirements

- Visual Studio Code v1.80.0 or higher
- Go 1.16 or higher installed and available in PATH
- `go` tools (`go fmt`, `go vet`) must be accessible from command line

## Installation

1. Open VS Code
2. Press `Ctrl+P` (or `Cmd+P` on macOS)
3. Type `ext install go-file-manager`
4. Press Enter

## Usage

### Adding Common Flow
1. Open a Go file
2. Press `Ctrl+Shift+P` (or `Cmd+Shift+P` on macOS)
3. Type "Add Common Flow"
4. Press Enter

### Sorting Functions
1. Open a Go file
2. Press `Ctrl+Shift+P` (or `Cmd+Shift+P` on macOS)
3. Type "Sort Functions Alphabetically"
4. Press Enter

### Using Go Tools
- Format Code: `Ctrl+Shift+P` → "Format Go Code"
- Run Vet: `Ctrl+Shift+P` → "Run Go Vet"
- Run Tests: `Ctrl+Shift+P` → "Run Go Tests"

## Extension Settings

This extension contributes the following settings:

* `go-file-manager.formatOnSave`: Enable/disable automatic formatting on save
* `go-file-manager.commonFlowTemplate`: Customize the common flow template
* `go-file-manager.vetOnSave`: Enable/disable running go vet on save

## Known Issues

- Function sorting currently doesn't handle interface methods
- Block comments (/* */) might need manual adjustment after sorting
- Go tools must be installed separately

## Release Notes

### 1.0.0
- Initial release
- Basic function sorting
- Common flow insertion
- Go tools integration

### 0.0.1
- Preview release with basic functionality

## Contributing

We welcome contributions! Please see our [contributing guidelines](https://github.com/ivikasavnish/gohelper/blob/HEAD/CONTRIBUTING.md) for details.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Building From Source

```bash
# Clone the repository
git clone https://github.com/yourusername/go-file-manager.git

# Install dependencies
npm install

# Compile
npm run compile

# Package
vsce package
```

## License

This project is licensed under the MIT License - see the [LICENSE](https://github.com/ivikasavnish/gohelper/blob/HEAD/LICENSE) file for details.

## Support

If you encounter any problems, please file an issue at [issue tracker](https://github.com/yourusername/go-file-manager/issues).

## Acknowledgments

- VS Code Extension team for their excellent documentation
- Go team for their fantastic tooling
- All contributors who have helped with the project

## Security

Please report security issues to security@yourdomain.com or via the GitHub security advisory system.

---

**Enjoy!**