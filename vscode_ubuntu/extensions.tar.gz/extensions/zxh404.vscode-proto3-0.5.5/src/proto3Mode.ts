'use strict';

import vscode = require('vscode');

export const PROTO3_MODE: vscode.DocumentFilter = {
    language: 'proto3',
    scheme: 'file'
};
