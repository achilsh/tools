# Go Test Explorer for VS Code
[![Build Status](https://travis-ci.org/ppparihar/GoTestExplorer.svg?branch=master)](https://travis-ci.org/ppparihar/GoTestExplorer)

![go-test-explorer](https://github.com/ppparihar/gotestexplorer/raw/master/media/gotest.gif)