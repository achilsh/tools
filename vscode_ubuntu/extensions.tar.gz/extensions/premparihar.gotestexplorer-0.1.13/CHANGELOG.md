# Change Log

## V0.1.10
- Added error message notification for any error occur while discovering tests.

## V0.1.9
- Execute test per test suite with the help of go tools to improve performace.
- Update test suite icon based on the test result

## V0.1.8
- Changed extension's icon

## V0.1.7
- Added parallel test execution limit to improve extention performance

## V0.1.5
- Improved performance of test loader

## V0.1.4
- Run all test from test suite at right click
- Improved performance of loading test result 