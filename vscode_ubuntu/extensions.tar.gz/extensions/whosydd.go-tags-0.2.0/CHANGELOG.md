# Change Log

## [0.2.0]

- 将该插件功能整合到 QuickFix 中
- 移除配置项
- 添加 Remove Tags 功能
- 添加 Add Omitempty 功能

## [0.1.0]

- Initial release
