# Go Tags

## Features

Use `QuickFix` to add tags.

### Add JSON Tag

![addjsontag](https://raw.githubusercontent.com/whosydd/images-in-one/main/images/202305242225948.gif)

### Add Tags

![addtags](https://raw.githubusercontent.com/whosydd/images-in-one/main/images/202305242230386.gif)

### Remove Tags

![removetags](https://raw.githubusercontent.com/whosydd/images-in-one/main/images/202305242233527.gif)

### Add Omitempty

![addomitempty](https://raw.githubusercontent.com/whosydd/images-in-one/main/images/202305242236891.gif)

## Thanks

icon by <a href="https://www.flaticon.com/free-icons/label" title="label icons"> Vectors Market - Flaticon</a>
