#!/bin/bash

which vsce >/dev/null || npm install -g @vscode/vsce
pnpm run publish
