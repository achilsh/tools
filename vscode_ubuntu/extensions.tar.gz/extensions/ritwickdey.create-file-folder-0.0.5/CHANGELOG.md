# Changelog

|Version|Date|Changelog|
|--|--|--|
|0.0.5|30.09.17| &mdash; Small Fixes |
|0.0.4|30.09.17| &mdash; Keyboard Shortcut added  <br> &mdash; Small Fixes |
|0.0.3|28.09.17| &mdash; File & Folder Detection Fixed |
|0.0.2|28.09.17| &mdash; Bug Fixed regarding backslash (`/`). <br> &mdash; Preloaded file path fixed. <br> &mdash; Intro Gif added in description.|
|0.0.1|27.09.17| &mdash; Initial release |