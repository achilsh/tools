**Please see https://github.com/golang/vscode-go/blob/master/CHANGELOG.md for the latest CHANGELOG.md**
