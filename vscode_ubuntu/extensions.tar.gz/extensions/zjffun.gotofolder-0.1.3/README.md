# Go to Folder

English | [简体中文](https://github.com/zjffun/vscode-go-to-folder/blob/HEAD/README.zh-CN.md)

Quick go to folder.

[![video](https://github.com/zjffun/vscode-go-to-folder/raw/HEAD/images/video.webp)](https://www.youtube.com/watch?v=ORRnb8-WRrc)

## Features

### Start go to folder by menu

![Go to folder by menu](https://github.com/zjffun/vscode-go-to-folder/raw/HEAD/images/go-to-folder-by-menu.webp)

### Start go to folder by command palette

![Go to folder by command palette](https://github.com/zjffun/vscode-go-to-folder/raw/HEAD/images/go-to-folder-by-command-palette.webp)

### Open folder in new window

![Open folder in new window](https://github.com/zjffun/vscode-go-to-folder/raw/HEAD/images/open-folder-in-new-window.webp)

## Install via CLI

```bash
code --install-extension zjffun.gotofolder
```

## [Release Notes](https://github.com/zjffun/vscode-go-to-folder/blob/HEAD/CHANGELOG.md)
