package main

import (
	"dash"
	"fmt"
	"happy"
)

func main() {
	fmt.Println(happy.Name())
	fmt.Println(dash.CleanUp())
	happy.Dat()
}
