package ending

import "fmt"

func Park() {
	fmt.Println("should not be enter")
}
