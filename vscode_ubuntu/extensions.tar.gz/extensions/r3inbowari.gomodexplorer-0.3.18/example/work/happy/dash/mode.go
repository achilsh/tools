package dash

func CleanUp() string {
	return "clean up"
}
