package unuse

func NoCall() string {
	return "byte"
}
